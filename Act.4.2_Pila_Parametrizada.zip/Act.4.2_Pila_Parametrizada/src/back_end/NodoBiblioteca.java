/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

import java.util.Objects;

/**
 *
 * @author coter
 */
public class NodoBiblioteca {
    private Trabajo dato;          // referencia polimórfica a la clase base
    private NodoBiblioteca siguiente;

    public NodoBiblioteca() {
    }

    public NodoBiblioteca(Trabajo dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    public Trabajo getDato() {
        return dato;
    }

    public void setDato(Trabajo dato) {
        this.dato = dato;
    }

    public NodoBiblioteca getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoBiblioteca siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.dato);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final NodoBiblioteca other = (NodoBiblioteca) obj;
        return Objects.equals(this.dato, other.dato);
    }

    @Override
    public String toString() {
        return "Nodo{" + "dato=" + dato + '}';
    }  
    
} // Final
