/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class ColaTrabajos {
    private NodoBiblioteca frente;   // primer elemento a atender
    private NodoBiblioteca fin;      // último elemento encolado
    private int tamaño;

    public ColaTrabajos() { // Constructor vacio
    }

    public ColaTrabajos(NodoBiblioteca frente, NodoBiblioteca fin, int tamaño) {// Constr con parametros
        this.frente = frente;
        this.fin = fin;
        this.tamaño = tamaño;
    }

//offer(Trabajo trabajo) / enqueue: encola una nueva publicación al final de la cola.
    public void offer(Trabajo dato){
        if (dato == null) {
            throw new IllegalArgumentException("No se puede encolar un trabajo nulo");
        }
        NodoBiblioteca nuevo = new NodoBiblioteca(dato);
        if(isEmpty()){
            frente = nuevo;
        }else {
            fin.setSiguiente(nuevo);
        }
        fin = nuevo;
        tamaño++; 
    }
    
//poll() / dequeue: atiende, remueve y devuelve el trabajo al frente de la cola.
    public Trabajo poll(){
         if (isEmpty()) {
            throw new IllegalStateException("No se puede atender: la cola está vacía");
        }
        Trabajo dato = frente.getDato();
        frente = frente.getSiguiente();
        if (frente == null) {
            fin = null;
        }
        tamaño--;
        return dato;
    }
    
//peek(): consulta el trabajo al frente sin removerlo.
    public Trabajo peek(){
        if (isEmpty()) {
            throw new IllegalStateException("No se puede consultar el frente: la cola está vacía");
        }
        return frente.getDato();
    }
    
//isEmpty(): verifica si la cola se encuentra vacía.
    public boolean isEmpty(){
        return frente == null;
    }
    
//vaciarCola(): elimina todos los trabajos de la cola.
    public void vaciarCola(){
        frente = null;
        fin = null;
        tamaño = 0;
    }    
    
//Metodo auxiliar/extra
    public String mostrarCola() {
        if (isEmpty()) return "La cola está vacía";
        StringBuilder sb = new StringBuilder();
        NodoBiblioteca actual = frente;
        int pos = 1;
        while (actual != null) {
            sb.append(pos).append(". ").append(actual.getDato()).append("\n");
            actual = actual.getSiguiente();
            pos++;
        }
        return sb.toString();
    }
  //Obtener tamaño (size): devolver la cantidad de elementos presentes.
    public int size() {
        return tamaño;
    }
  // Recorre del frente al final y devuelve un arreglo
    public Trabajo[] listarDelFrenteAlFinal() {
        Trabajo[] arreglo = new Trabajo[size()];
        NodoBiblioteca actual = frente;
        int i = 0;
        while (actual != null) {
            arreglo[i++] = actual.getDato();
            actual = actual.getSiguiente();
        }
        return arreglo;
    }
}//Final
